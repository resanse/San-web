package controller

import (
	"GinSql/service"
	"github.com/gin-gonic/gin"
)

func Register(ctx *gin.Context)  {
	res:=service.Register(ctx)
	if res{
	ctx.JSON(200,gin.H{
		"message":"success",
	})
	}else {
		ctx.JSON(200,gin.H{
			"message":"failed",
		})
	}

}
func Login(ctx *gin.Context)  {
	res:=service.Login(ctx)
	if res{
		ctx.JSON(200,gin.H{
			"message":"success",
		})
	}else {
		ctx.JSON(200,gin.H{
			"message":"failed",
		})
	}

}
func Charge(ctx *gin.Context)  {
	res:=service.Charge(ctx)
	if res{
		ctx.JSON(200,gin.H{
			"message":"success",
		})
	}else {
		ctx.JSON(200,gin.H{
			"message":"failed",
		})
	}
}